function Lambda = getLambda(p, I, J, K, alpha0, rho, beta, delta)
% p:      Weights to each sequence (must add up to one)
% I:      Number of clusters
% J:      Number of time periods
% K:      Number of patients per cluster per time period
% alpha0: Used in covariance structure
% rho:    Used in covariance structure
% beta:   Period effects, for periods 1, 2, 3, ... , T (must be 1xT vector)
% delta:  Treatment effect

% Get covariance matrix for treatment effects
Var_theta = getVarTheta(p, I, J, K, alpha0, rho, beta, delta);
% Extract Var_delta and take the log
Lambda    = log(Var_theta(J + 1, J + 1));
end