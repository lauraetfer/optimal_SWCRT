function diff = rootComparator(I, J, K, alpha0, rho, lb, ub, X, p_opt, p_comp)
% I:      Number of clusters
% J:      Number of time periods
% K:      Number of patients per cluster per time period
% alpha0: Used in covariance structure
% rho:    Used in covariance structure
% lb:     Lower bounds for the parameters
% ub:     Upper bounds for the parameters
% X:      LHS grid
% p_opt:  Optimal weights
% p_comp: Comparator design weights

% Get performance of the optimal design
exp_psi_opt = exp(getPsi(p_opt, 1, J, K, alpha0, rho, lb, ub, X));
% Get performance of the comparator design
exp_psi_bal = exp(getPsi(p_comp, I, J, K, alpha0, rho, lb, ub, X));
diff        = exp_psi_bal - exp_psi_opt;
end