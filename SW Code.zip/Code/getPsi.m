function Psi = getPsi(p, I, J, K, alpha0, rho, lb, ub, X)
% p:      Weights to each sequence (must add up to one)
% I:      Number of clusters
% J:      Number of time periods
% K:      Number of patients per cluster per time period
% alpha0: Used in covariance structure
% rho:    Used in covariance structure
% lb:     Lower bounds for the parameters
% ub:     Upper bounds for the parameters
% X:      LHS grid

% Create the values of theta at which to compute Lambda. Based on
% lb + X*(ub - lb) where X is chosen using LHS
theta       = bsxfun(@plus, lb, bsxfun(@times, X, ub - lb));
% Loop over the rows of theta, computing Lambda for each value
n           = size(X, 2);
Lambda      = zeros(n, 1);
for i = 1:n
  Lambda(i) = getLambda(p, I, J, K, alpha0, rho, theta(1:J, i), theta(J + 1, i));
end
Psi         = mean(Lambda);
end