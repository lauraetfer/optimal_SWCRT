%%%%% Example 1: Washington State EPT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Fixed design parameters
I              = 22;
J              = 5;
K              = mean([ 77,  78,   94,  122,  133;
                        19,  59,  109,  122,  101;
                        78,  58,   41,   52,   48;
                       421, 568,  550,  844, 1050;
                        36,  57,   62,   79,  131;
                        49,  44,   51,   83,   54;
                        17,  58,   79,   99,   59;
                       117, 132,  129,  224,  316;
                       135, 223,  250,  382,  855;
                       333, 848, 1189, 1325, 1050;
                       231, 318,  293,  305,  352;
                        48,  67,   73,  120,  166;
                        26,  44,   65,   83,   96;
                       221, 270,  276,  356,  225;
                       168, 272,  396,  476,  423;
                       359, 396,  329,  397,  354;
                        45, 212,  199,   79,  131;
                        64, 261,  176,  133,  90;
                       493, 590,  532,  785,  961;
                        26,  67,  115,  174,   94;
                       374, 482,  591,  616,  557;
                       608, 787, 1075, 1553, 1370], "all");
% Set up LHS grid
X              = lhsdesign(100, J + 1)';
% Balanced design
p_bal          = ones(J - 1, 1)/(J - 1);
% Optimal design for simple exchangeable structure
alpha0_sim     = 0.0051;
rho_sim        = 1;
se_sim         = [0.091; 0.091; 0.094; 0.106; 0.145; 0.092];
theta_sim      = [-2.443; -2.454; -2.535; -2.609; -2.537; -0.141];
lb_sim         = theta_sim - norminv(0.975, 0, 1)*se_sim;
ub_sim         = theta_sim + norminv(0.975, 0, 1)*se_sim;
p_sim          = getOptimal(I, J, K, alpha0_sim, rho_sim, lb_sim, ub_sim, X);
% Lawrie design for simple exchangeable structure
p_lawrie       = getLawrie(J, K, alpha0_sim);
% Optimal design for exponential decay structure
alpha0_exp     = 0.0070;
rho_exp        = 0.7157;
se_exp         = [0.095; 0.089; 0.100; 0.115; 0.131; 0.087];
theta_exp      = [-2.437; -2.444; -2.508; -2.613; -2.552; -0.124];
lb_exp         = theta_exp - norminv(0.975, 0, 1)*se_exp;
ub_exp         = theta_exp + norminv(0.975, 0, 1)*se_exp;
p_exp          = getOptimal(I, J, K, alpha0_exp, rho_exp, lb_exp, ub_exp, X);
% Performance of the four designs for the two correlation structures
psi_bal_sim    = getPsi(p_bal, I, J, K, alpha0_sim, rho_sim, lb_sim, ub_sim, X);
psi_sim_sim    = getPsi(p_sim, I, J, K, alpha0_sim, rho_sim, lb_sim, ub_sim, X);
psi_lawrie_sim = getPsi(p_lawrie, I, J, K, alpha0_sim, rho_sim, lb_sim, ub_sim, X);
psi_exp_sim    = getPsi(p_exp, I, J, K, alpha0_sim, rho_sim, lb_sim, ub_sim, X);
psi_bal_exp    = getPsi(p_bal, I, J, K, alpha0_exp, rho_exp, lb_exp, ub_exp, X);
psi_sim_exp    = getPsi(p_sim, I, J, K, alpha0_exp, rho_exp, lb_exp, ub_exp, X);
psi_lawrie_exp = getPsi(p_lawrie, I, J, K, alpha0_exp, rho_exp, lb_exp, ub_exp, X);
psi_exp_exp    = getPsi(p_exp, I, J, K, alpha0_exp, rho_exp, lb_exp, ub_exp, X);
root_I_bal     = @(I) rootComparator(I, J, K, alpha0_sim, rho_sim, lb_sim, ub_sim, X, p_sim, p_bal);
I_bal_sim      = fzero(root_I_bal, 1);
root_I_lawrie  = @(I) rootComparator(I, J, K, alpha0_sim, rho_sim, lb_sim, ub_sim, X, p_sim, p_lawrie);
I_lawrie_sim   = fzero(root_I_lawrie, 1);
root_I_exp     = @(I) rootComparator(I, J, K, alpha0_sim, rho_sim, lb_sim, ub_sim, X, p_sim, p_exp);
I_exp_sim      = fzero(root_I_exp, 1);
root_I_bal     = @(I) rootComparator(I, J, K, alpha0_exp, rho_exp, lb_exp, ub_exp, X, p_exp, p_bal);
I_bal_exp      = fzero(root_I_bal, 1);
root_I_sim     = @(I) rootComparator(I, J, K, alpha0_exp, rho_exp, lb_exp, ub_exp, X, p_exp, p_sim);
I_sim_exp      = fzero(root_I_sim, 1);
root_I_lawrie  = @(I) rootComparator(I, J, K, alpha0_exp, rho_exp, lb_exp, ub_exp, X, p_exp, p_lawrie);
I_lawrie_exp   = fzero(root_I_lawrie, 1);

%%%%% Example 2: Hypothetical trial %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

I                       = 1;
J                       = 9;
p_bal                   = ones(J - 1, 1)/(J - 1);
K                       = [10, 50, 100];
alpha0                  = 0.01:0.01:0.10;
rho                     = 0.50:0.05:1.00;
a                       = -0.50:0.10:0.50;
b                       = 0.00:0.10:1.00;
scenarios               = [combvec(50, 0.01, 0.5, a, b)';
                           combvec(50, 0.01, 1.0, a, b)';
                           combvec(50, 0.05, 0.5, a, b)';
                           combvec(50, 0.05, 1.0, a, b)';
                           combvec(K, alpha0, rho, -0.1, 0.5)';
                           combvec(K, alpha0, rho, -0.5, 1)'];
X                       = lhsdesign(100, J + 1)';
p_opt                   = zeros(size(scenarios, 1), J - 1);
I_bal                   = zeros(size(scenarios, 1), 1);
I_lawrie                = I_bal;
for i = 1:size(p_opt, 1)
  [theta_i, lb_i, ub_i] = getTheta(J - 1, J, 5, scenarios(i, 2), scenarios(i, 3), 0.1, scenarios(i, 4), scenarios(i, 5), log(2.25));
  p_opt(i, :)           = getOptimal(I, J, scenarios(i, 1), scenarios(i, 2), scenarios(i, 3), lb_i, ub_i, X);
  psi_opt_i             = getPsi(p_opt(i, :), I, J, scenarios(i, 1), scenarios(i, 2), scenarios(i, 3), lb_i, ub_i, X);
  psi_bal_i             = getPsi(p_bal, I, J, scenarios(i, 1), scenarios(i, 2), scenarios(i, 3), lb_i, ub_i, X);
  p_lawrie_i            = getLawrie(J, scenarios(i, 1), scenarios(i, 2))';
  psi_lawrie_i          = getPsi(p_lawrie_i, I, J, scenarios(i, 1), scenarios(i, 2), scenarios(i, 3), lb_i, ub_i, X);
  I_bal(i)              = exp(psi_bal_i)/exp(psi_opt_i);
  I_lawrie(i)           = exp(psi_lawrie_i)/exp(psi_opt_i);
end
writematrix([scenarios, p_opt, I_bal, I_lawrie], "results")
