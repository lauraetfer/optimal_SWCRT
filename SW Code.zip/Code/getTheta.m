function [theta, lb, ub] = getTheta(I, J, K, alpha0, rho, beta1, a, b, delta)
% I:      Number of clusters
% J:      Number of time periods
% K:      Number of patients per cluster per time period
% alpha0: Used in covariance structure
% rho:    Used in covariance structure
% beta1:  Period 1 effect
% a:      Used in specifying beta
% b:      Used in specifying beta
% J:      Number of time periods
% delta:  Treatment effect

beta      = [beta1; zeros(J - 1, 1)];
for j = 2:J
  beta(j) = beta(j - 1) + a*(b^(j - 1));
end
theta     = [beta; delta];
se        = diag(sqrt(getVarTheta(ones(J - 1, 1)/(J - 1), I, J, K, alpha0, rho, beta, delta)));
lb        = theta - norminv(0.9, 0, 1)*se;
ub        = theta + norminv(0.9, 0, 1)*se;
end