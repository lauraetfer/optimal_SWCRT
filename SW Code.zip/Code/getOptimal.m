function [p_opt, psi_opt] = getOptimal(I, J, K, alpha0, rho, lb, ub, X)
% I:      Number of clusters
% J:      Number of time periods
% K:      Number of patients per cluster per time period
% alpha0: Used in covariance structure
% rho:    Used in covariance structure
% lb:     Lower bounds for the parameters
% ub:     Upper bounds for the parameters
% X:      LHS grid

options          = optimoptions('fmincon', 'Algorithm', 'interior-point', 'TolFun', 1e-44, 'TolCon', 1e-44, 'MaxFunEvals', 1000000, 'Display', 'off');
[p_opt, psi_opt] = fmincon(@(ps)getPsi(ps, I, J, K, alpha0, rho, lb, ub, X), ones(1, J - 1)/(J - 1), [], [], ones(1, J - 1), 1, zeros(J - 1, 1), ones(J - 1, 1), [], options);
end