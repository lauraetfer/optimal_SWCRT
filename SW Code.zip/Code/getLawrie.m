function p_lawrie = getLawrie(J, K, alpha0)
% J:      Number of time periods
% K:      Number of patients per cluster per time period
% alpha0: Used in covariance structure

p_lawrie            = zeros(1, J - 1);
p_lawrie(1)         = (1 + alpha0*(3*K - 1))/(2*(1 + alpha0*(J*K - 1)));
p_lawrie(J - 1)     = p_lawrie(1);
p_lawrie(2:(J - 2)) = K*alpha0/(1 + alpha0*(J*K - 1));

end