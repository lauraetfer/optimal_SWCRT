function Var_theta = getVarTheta(p, I, J, K, alpha0, rho, beta, delta)
% p:      Weights to each sequence (must add up to one)
% I:      Number of clusters
% J:      Number of time periods
% K:      Number of patients per cluster per time period
% alpha0: Used in covariance structure
% rho:    Used in covariance structure
% beta:   Period effects, for periods 1, 2, 3, ... , T (must be Tx1 vector)
% delta:  Treatment effect

% Initialise matrix to store Var_theta^{-1}
Var_theta_inv   = zeros(J + 1);
% Initialise matrix to store Vj
Vj              = zeros(J);
% Loop over sequences
for j = 1:(J - 1)
  % Column of design matrix relating to sequence
  Xj            = [zeros(j, 1); ones(J - j, 1)];
  % Compute muj
  etaj          = beta + Xj*delta;
  muj           = exp(etaj)./(1 + exp(etaj));
  % Compute Vj
  nuj           = muj.*(1 - muj);
  for l = 1:J
    Vj(l, l)    = nuj(l)*(1 + (K - 1)*alpha0)/K;
  end
  for l = 1:(J - 1)
    for m = (l + 1):J
      Vj(l, m)  = sqrt(nuj(l))*sqrt(nuj(m))*alpha0*rho^abs(l - m);
      Vj(m, l)  = Vj(l, m);
    end
  end
  % Compute Dj
  Dj            = diag(nuj)*[eye(J) Xj];
  % Add required component of Var_theta_inv
  Var_theta_inv = Var_theta_inv + I*p(j)*Dj'*inv(Vj)*Dj;
end
% Take inverse
Var_theta       = inv(Var_theta_inv);
end